import React from 'react'

const SideBar = () => {
    return (
        <div className='sidebar'>SideBar</div>
    )
}

export default SideBar